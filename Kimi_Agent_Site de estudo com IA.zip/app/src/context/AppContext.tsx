import { createContext, useContext } from 'react';
import type { ReactNode } from 'react';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import type { ScheduleItem, Test, Video, IAHistory } from '@/types';

interface AppContextType {
  schedule: ScheduleItem[];
  setSchedule: (value: ScheduleItem[] | ((prev: ScheduleItem[]) => ScheduleItem[])) => void;
  tests: Test[];
  setTests: (value: Test[] | ((prev: Test[]) => Test[])) => void;
  videos: Video[];
  setVideos: (value: Video[] | ((prev: Video[]) => Video[])) => void;
  iaHistory: IAHistory[];
  setIaHistory: (value: IAHistory[] | ((prev: IAHistory[]) => IAHistory[])) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [schedule, setSchedule] = useLocalStorage<ScheduleItem[]>('studyhub_schedule', []);
  const [tests, setTests] = useLocalStorage<Test[]>('studyhub_tests', []);
  const [videos, setVideos] = useLocalStorage<Video[]>('studyhub_videos', []);
  const [iaHistory, setIaHistory] = useLocalStorage<IAHistory[]>('studyhub_ia_history', []);

  return (
    <AppContext.Provider value={{ schedule, setSchedule, tests, setTests, videos, setVideos, iaHistory, setIaHistory }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
}
