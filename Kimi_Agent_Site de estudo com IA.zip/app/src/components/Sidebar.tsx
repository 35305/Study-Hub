import { NavLink } from 'react-router-dom';
import { Home, Calendar, FileText, Play, Brain, GraduationCap, Menu, X } from 'lucide-react';
import { useState } from 'react';

const navItems = [
  { to: '/', icon: Home, label: 'Home' },
  { to: '/horario', icon: Calendar, label: 'Horário' },
  { to: '/testes', icon: FileText, label: 'Testes' },
  { to: '/videos', icon: Play, label: 'Vídeos' },
  { to: '/ia', icon: Brain, label: 'IA' },
];

export default function Sidebar() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <>
      {/* Mobile menu button */}
      <button
        onClick={() => setMobileOpen(!mobileOpen)}
        className="lg:hidden fixed top-4 left-4 z-50 p-2 rounded-lg bg-[#1e293b] text-white shadow-lg"
      >
        {mobileOpen ? <X size={20} /> : <Menu size={20} />}
      </button>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black/50 z-40"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`
          fixed top-0 left-0 z-40 h-full bg-[#0f172a] border-r border-[#334155]
          transition-transform duration-300 ease-in-out
          lg:translate-x-0 lg:w-[240px]
          ${mobileOpen ? 'translate-x-0 w-[240px]' : '-translate-x-full w-[240px]'}
        `}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 px-5 py-6 border-b border-[#334155]">
          <GraduationCap size={28} className="text-blue-500" />
          <span className="text-xl font-bold text-white">StudyHub</span>
        </div>

        {/* Navigation */}
        <nav className="flex flex-col gap-1 p-3 mt-2">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              onClick={() => setMobileOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200 ${
                  isActive
                    ? 'bg-[#1e293b] text-blue-400 border-l-[3px] border-blue-500'
                    : 'text-[#94a3b8] hover:bg-[#1e293b] hover:text-white border-l-[3px] border-transparent'
                }`
              }
            >
              <item.icon size={20} />
              <span>{item.label}</span>
            </NavLink>
          ))}
        </nav>

        {/* Footer */}
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-[#334155]">
          <p className="text-xs text-[#64748b] text-center">StudyHub v1.0</p>
        </div>
      </aside>
    </>
  );
}
