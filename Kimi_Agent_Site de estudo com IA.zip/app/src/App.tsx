import { Routes, Route } from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import Layout from './components/Layout';
import Home from './pages/Home';
import Horario from './pages/Horario';
import Testes from './pages/Testes';
import Videos from './pages/Videos';
import IA from './pages/IA';

export default function App() {
  return (
    <AppProvider>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/horario" element={<Horario />} />
          <Route path="/testes" element={<Testes />} />
          <Route path="/videos" element={<Videos />} />
          <Route path="/ia" element={<IA />} />
        </Routes>
      </Layout>
    </AppProvider>
  );
}
