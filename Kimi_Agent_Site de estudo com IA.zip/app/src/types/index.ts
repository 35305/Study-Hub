export interface ScheduleItem {
  id: string;
  day: 'mon' | 'tue' | 'wed' | 'thu' | 'fri' | 'sat';
  startTime: string;
  endTime: string;
  subject: string;
  color: string;
}

export interface Test {
  id: string;
  subject: string;
  date: string;
  topic: string;
  completed: boolean;
}

export interface Video {
  id: string;
  url: string;
  title: string;
  discipline: string;
  thumbnail: string;
  dateAdded: string;
}

export interface IAHistory {
  id: string;
  image: string;
  mode: 'summarize' | 'quiz' | 'explain' | 'flashcards';
  prompt: string;
  response: string;
  timestamp: string;
}

export type IAMode = 'summarize' | 'quiz' | 'explain' | 'flashcards';

export interface Flashcard {
  front: string;
  back: string;
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswer: number;
}

export type DayOfWeek = 'mon' | 'tue' | 'wed' | 'thu' | 'fri' | 'sat';

export const DAYS_PT: Record<DayOfWeek, string> = {
  mon: 'Segunda',
  tue: 'Terça',
  wed: 'Quarta',
  thu: 'Quinta',
  fri: 'Sexta',
  sat: 'Sábado',
};

export const DISCIPLINE_COLORS = [
  { name: 'Azul', value: '#3b82f6' },
  { name: 'Verde', value: '#10b981' },
  { name: 'Roxo', value: '#8b5cf6' },
  { name: 'Laranja', value: '#f97316' },
  { name: 'Rosa', value: '#ec4899' },
  { name: 'Teal', value: '#14b8a6' },
  { name: 'Âmbar', value: '#f59e0b' },
  { name: 'Vermelho', value: '#ef4444' },
];

export const HOURS = Array.from({ length: 13 }, (_, i) => {
  const hour = i + 8;
  return `${hour.toString().padStart(2, '0')}:00`;
});
