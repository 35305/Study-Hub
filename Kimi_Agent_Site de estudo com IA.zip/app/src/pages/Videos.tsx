import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Plus, X, Trash2, Play, Search } from 'lucide-react';

function extractYouTubeId(url: string): string | null {
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\s?]+)/,
    /^([a-zA-Z0-9_-]{11})$/,
  ];
  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) return match[1];
  }
  return null;
}

function getYouTubeThumbnail(videoId: string): string {
  return `https://img.youtube.com/vi/${videoId}/mqdefault.jpg`;
}

export default function Videos() {
  const { videos, setVideos } = useApp();
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({ url: '', title: '', discipline: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [searchQuery, setSearchQuery] = useState('');
  const [disciplineFilter, setDisciplineFilter] = useState('');

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.url.trim()) errs.url = 'URL obrigatória';
    else if (!extractYouTubeId(formData.url)) errs.url = 'URL do YouTube inválida';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;

    const videoId = extractYouTubeId(formData.url);
    if (!videoId) return;

    const newVideo = {
      id: crypto.randomUUID(),
      url: formData.url,
      title: formData.title.trim() || `Vídeo ${videoId}`,
      discipline: formData.discipline.trim(),
      thumbnail: getYouTubeThumbnail(videoId),
      dateAdded: new Date().toISOString(),
    };

    setVideos((prev) => [newVideo, ...prev]);
    setFormData({ url: '', title: '', discipline: '' });
    setShowForm(false);
    setErrors({});
  };

  const handleDelete = (id: string) => {
    setVideos((prev) => prev.filter((v) => v.id !== id));
  };

  const uniqueDisciplines = Array.from(new Set(videos.map((v) => v.discipline).filter(Boolean)));

  const filteredVideos = videos.filter((v) => {
    const matchesSearch =
      !searchQuery ||
      v.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      v.discipline.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDiscipline = !disciplineFilter || v.discipline === disciplineFilter;
    return matchesSearch && matchesDiscipline;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-white">Vídeos de Estudo</h1>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium text-sm transition-colors"
        >
          {showForm ? <X size={16} /> : <Plus size={16} />}
          {showForm ? 'Cancelar' : 'Adicionar Vídeo'}
        </button>
      </div>

      {/* Add Form */}
      {showForm && (
        <div className="bg-[#1e293b] rounded-xl border border-[#334155] p-5">
          <h3 className="text-sm font-semibold text-white mb-4">Novo Vídeo</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-1">
              <label className="block text-xs font-medium text-[#94a3b8] uppercase tracking-wider mb-1.5">
                URL do YouTube *
              </label>
              <input
                type="text"
                value={formData.url}
                onChange={(e) => setFormData((prev) => ({ ...prev, url: e.target.value }))}
                placeholder="https://youtube.com/watch?v=..."
                className={`w-full px-3 py-2.5 bg-[#0f172a] border rounded-lg text-white text-sm placeholder-[#475569] focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  errors.url ? 'border-red-500' : 'border-[#334155]'
                }`}
              />
              {errors.url && <p className="text-red-400 text-xs mt-1">{errors.url}</p>}
            </div>
            <div>
              <label className="block text-xs font-medium text-[#94a3b8] uppercase tracking-wider mb-1.5">
                Título
              </label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData((prev) => ({ ...prev, title: e.target.value }))}
                placeholder="Auto-detect se vazio"
                className="w-full px-3 py-2.5 bg-[#0f172a] border border-[#334155] rounded-lg text-white text-sm placeholder-[#475569] focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[#94a3b8] uppercase tracking-wider mb-1.5">
                Disciplina
              </label>
              <input
                type="text"
                value={formData.discipline}
                onChange={(e) => setFormData((prev) => ({ ...prev, discipline: e.target.value }))}
                placeholder="Ex: Matemática"
                className="w-full px-3 py-2.5 bg-[#0f172a] border border-[#334155] rounded-lg text-white text-sm placeholder-[#475569] focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
          <button
            onClick={handleSubmit}
            className="mt-4 px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium text-sm transition-colors"
          >
            Guardar Vídeo
          </button>
        </div>
      )}

      {/* Search & Filter */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#475569]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Pesquisar vídeos..."
            className="w-full pl-9 pr-3 py-2.5 bg-[#1e293b] border border-[#334155] rounded-lg text-white text-sm placeholder-[#475569] focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        {uniqueDisciplines.length > 0 && (
          <select
            value={disciplineFilter}
            onChange={(e) => setDisciplineFilter(e.target.value)}
            className="px-3 py-2.5 bg-[#1e293b] border border-[#334155] rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">Todas as disciplinas</option>
            {uniqueDisciplines.map((d) => (
              <option key={d} value={d}>{d}</option>
            ))}
          </select>
        )}
      </div>

      {/* Videos Grid */}
      {filteredVideos.length === 0 ? (
        <div className="bg-[#1e293b] rounded-xl border border-[#334155] p-12 text-center">
          <Play size={40} className="text-[#334155] mx-auto mb-3" />
          <p className="text-[#64748b] text-sm">
            {videos.length === 0 ? 'Ainda não tens vídeos guardados' : 'Nenhum vídeo encontrado'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredVideos.map((video) => (
            <div
              key={video.id}
              className="bg-[#1e293b] rounded-xl border border-[#334155] overflow-hidden hover:border-[#475569] transition-all duration-200 group"
            >
              {/* Thumbnail */}
              <a
                href={video.url}
                target="_blank"
                rel="noopener noreferrer"
                className="block relative aspect-video bg-[#0f172a] overflow-hidden"
              >
                <img
                  src={video.thumbnail}
                  alt={video.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                />
                <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <Play size={36} className="text-white" />
                </div>
              </a>

              {/* Info */}
              <div className="p-4">
                <a
                  href={video.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block"
                >
                  <h3 className="text-sm font-medium text-white line-clamp-2 hover:text-blue-400 transition-colors">
                    {video.title}
                  </h3>
                </a>
                <div className="flex items-center justify-between mt-3">
                  {video.discipline && (
                    <span className="px-2 py-0.5 bg-blue-500/10 text-blue-400 text-xs rounded-full">
                      {video.discipline}
                    </span>
                  )}
                  <button
                    onClick={() => handleDelete(video.id)}
                    className="p-1.5 text-[#475569] hover:text-red-400 transition-colors ml-auto"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
