import { useApp } from '@/context/AppContext';
import { Calendar, BookOpen, Play, CheckCircle, FileText, Brain, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { format, differenceInDays, parseISO, isFuture } from 'date-fns';
import { pt } from 'date-fns/locale';

export default function Home() {
  const { tests, schedule, videos } = useApp();

  const now = new Date();
  const dayNames = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'] as const;
  const todayKey = dayNames[now.getDay()] as 'mon' | 'tue' | 'wed' | 'thu' | 'fri' | 'sat';

  // Stats
  const upcomingTests = tests
    .filter((t) => !t.completed && isFuture(parseISO(t.date)))
    .sort((a, b) => parseISO(a.date).getTime() - parseISO(b.date).getTime());

  const nextTestDays = upcomingTests.length > 0
    ? differenceInDays(parseISO(upcomingTests[0].date), now)
    : null;

  const todaySchedule = schedule.filter((s) => s.day === todayKey);
  const todayScheduleSorted = todaySchedule.sort((a, b) => a.startTime.localeCompare(b.startTime));

  const recentVideos = [...videos]
    .sort((a, b) => new Date(b.dateAdded).getTime() - new Date(a.dateAdded).getTime())
    .slice(0, 4);

  const stats = [
    {
      icon: Calendar,
      label: 'Próximo teste',
      value: nextTestDays !== null ? `${nextTestDays} dias` : 'Nenhum',
      color: 'text-blue-500',
      bg: 'bg-blue-500/10',
    },
    {
      icon: BookOpen,
      label: 'Disciplinas hoje',
      value: `${todaySchedule.length}`,
      color: 'text-emerald-500',
      bg: 'bg-emerald-500/10',
    },
    {
      icon: Play,
      label: 'Vídeos guardados',
      value: `${videos.length}`,
      color: 'text-violet-500',
      bg: 'bg-violet-500/10',
    },
    {
      icon: CheckCircle,
      label: 'Testes concluídos',
      value: `${tests.filter((t) => t.completed).length}`,
      color: 'text-amber-500',
      bg: 'bg-amber-500/10',
    },
  ];

  const getDaysBadge = (date: string) => {
    const days = differenceInDays(parseISO(date), now);
    if (days < 0) return { text: 'Concluído', class: 'bg-[#334155] text-[#64748b]' };
    if (days === 0) return { text: 'Hoje!', class: 'bg-red-500/20 text-red-400 animate-pulse' };
    if (days <= 2) return { text: `${days}d`, class: 'bg-red-500/20 text-red-400' };
    if (days <= 7) return { text: `${days}d`, class: 'bg-amber-500/20 text-amber-400' };
    return { text: `${days}d`, class: 'bg-emerald-500/20 text-emerald-400' };
  };

  return (
    <div className="space-y-8">
      {/* Welcome Header */}
      <div>
        <h1 className="text-2xl lg:text-3xl font-bold text-white">Bem-vindo ao StudyHub</h1>
        <p className="text-[#94a3b8] mt-1">
          {format(now, "EEEE, d 'de' MMMM 'de' yyyy", { locale: pt })}
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <div
            key={stat.label}
            className="bg-[#1e293b] rounded-xl p-4 border border-[#334155] hover:border-[#475569] transition-all duration-200"
          >
            <div className={`w-10 h-10 rounded-lg ${stat.bg} flex items-center justify-center mb-3`}>
              <stat.icon size={20} className={stat.color} />
            </div>
            <p className="text-2xl font-bold text-white font-mono">{stat.value}</p>
            <p className="text-xs text-[#64748b] uppercase tracking-wider mt-1">{stat.label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Tests */}
        <div className="bg-[#1e293b] rounded-xl border border-[#334155] p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-white flex items-center gap-2">
              <FileText size={18} className="text-blue-500" />
              Próximos Testes
            </h2>
            <Link to="/testes" className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1">
              Ver todos <ArrowRight size={12} />
            </Link>
          </div>
          {upcomingTests.length === 0 ? (
            <div className="text-center py-8">
              <FileText size={32} className="text-[#334155] mx-auto mb-2" />
              <p className="text-[#64748b] text-sm">Ainda não tens testes marcados</p>
              <Link to="/testes" className="text-blue-400 text-sm hover:underline mt-1 inline-block">
                Marcar um teste
              </Link>
            </div>
          ) : (
            <div className="space-y-3">
              {upcomingTests.slice(0, 3).map((test) => {
                const badge = getDaysBadge(test.date);
                return (
                  <div
                    key={test.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-[#0f172a] border border-[#334155]"
                  >
                    <div>
                      <p className="font-medium text-white text-sm">{test.subject}</p>
                      <p className="text-xs text-[#64748b]">
                        {test.topic || format(parseISO(test.date), 'dd/MM/yyyy')}
                      </p>
                    </div>
                    <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${badge.class}`}>
                      {badge.text}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Today's Schedule */}
        <div className="bg-[#1e293b] rounded-xl border border-[#334155] p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-white flex items-center gap-2">
              <Calendar size={18} className="text-emerald-500" />
              Horário de Hoje
            </h2>
            <Link to="/horario" className="text-xs text-emerald-400 hover:text-emerald-300 flex items-center gap-1">
              Ver horário <ArrowRight size={12} />
            </Link>
          </div>
          {todayScheduleSorted.length === 0 ? (
            <div className="text-center py-8">
              <Calendar size={32} className="text-[#334155] mx-auto mb-2" />
              <p className="text-[#64748b] text-sm">Sem disciplinas hoje</p>
              <Link to="/horario" className="text-emerald-400 text-sm hover:underline mt-1 inline-block">
                Adicionar disciplinas
              </Link>
            </div>
          ) : (
            <div className="space-y-2">
              {todayScheduleSorted.map((item) => (
                <div
                  key={item.id}
                  className="flex items-center gap-3 p-3 rounded-lg bg-[#0f172a] border border-[#334155]"
                >
                  <div
                    className="w-2 h-10 rounded-full"
                    style={{ backgroundColor: item.color }}
                  />
                  <div className="flex-1">
                    <p className="font-medium text-white text-sm">{item.subject}</p>
                    <p className="text-xs text-[#64748b]">
                      {item.startTime} - {item.endTime}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Recent Videos */}
      <div className="bg-[#1e293b] rounded-xl border border-[#334155] p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-white flex items-center gap-2">
            <Play size={18} className="text-violet-500" />
            Vídeos Recentes
          </h2>
          <Link to="/videos" className="text-xs text-violet-400 hover:text-violet-300 flex items-center gap-1">
            Ver todos <ArrowRight size={12} />
          </Link>
        </div>
        {recentVideos.length === 0 ? (
          <div className="text-center py-8">
            <Play size={32} className="text-[#334155] mx-auto mb-2" />
            <p className="text-[#64748b] text-sm">Ainda não tens vídeos guardados</p>
            <Link to="/videos" className="text-violet-400 text-sm hover:underline mt-1 inline-block">
              Adicionar vídeos
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {recentVideos.map((video) => (
              <div key={video.id} className="group cursor-pointer">
                <div className="aspect-video rounded-lg overflow-hidden bg-[#0f172a] border border-[#334155] mb-2">
                  <img
                    src={video.thumbnail}
                    alt={video.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                  />
                </div>
                <p className="text-sm text-white line-clamp-2">{video.title}</p>
                {video.discipline && (
                  <span className="text-xs text-[#64748b] mt-1">{video.discipline}</span>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Quick CTA to IA */}
      <div className="bg-gradient-to-r from-blue-600/20 to-violet-600/20 rounded-xl border border-blue-500/30 p-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center">
            <Brain size={24} className="text-blue-400" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">Assistente de Estudo IA</h3>
            <p className="text-sm text-[#94a3b8]">Tira fotos dos teus manuais e obtém resumos, testes e explicações</p>
          </div>
        </div>
        <Link
          to="/ia"
          className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium text-sm transition-colors whitespace-nowrap"
        >
          Experimentar
        </Link>
      </div>
    </div>
  );
}
