import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Plus, X, Trash2, Edit3 } from 'lucide-react';
import { DAYS_PT, HOURS, DISCIPLINE_COLORS } from '@/types';
import type { ScheduleItem, DayOfWeek } from '@/types';

export default function Horario() {
  const { schedule, setSchedule } = useApp();
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    day: 'mon' as DayOfWeek,
    startTime: '08:00',
    endTime: '09:00',
    subject: '',
    color: '#3b82f6',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number; item: ScheduleItem } | null>(null);

  const days: DayOfWeek[] = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat'];

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.subject.trim()) errs.subject = 'Nome da disciplina obrigatório';
    if (formData.startTime >= formData.endTime) errs.time = 'Hora de fim deve ser depois da hora de início';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;

    if (editingId) {
      setSchedule((prev) =>
        prev.map((item) => (item.id === editingId ? { ...formData, id: editingId } : item))
      );
    } else {
      const newItem: ScheduleItem = {
        ...formData,
        id: crypto.randomUUID(),
      };
      setSchedule((prev) => [...prev, newItem]);
    }

    resetForm();
  };

  const resetForm = () => {
    setShowModal(false);
    setEditingId(null);
    setFormData({ day: 'mon', startTime: '08:00', endTime: '09:00', subject: '', color: '#3b82f6' });
    setErrors({});
  };

  const handleEdit = (item: ScheduleItem) => {
    setFormData({
      day: item.day,
      startTime: item.startTime,
      endTime: item.endTime,
      subject: item.subject,
      color: item.color,
    });
    setEditingId(item.id);
    setShowModal(true);
    setContextMenu(null);
  };

  const handleDelete = (id: string) => {
    setSchedule((prev) => prev.filter((item) => item.id !== id));
    setContextMenu(null);
  };

  const getScheduleForCell = (day: DayOfWeek, hour: string) => {
    return schedule.filter((s) => s.day === day && s.startTime <= hour && s.endTime > hour);
  };

  const handleCellClick = (day: DayOfWeek, hour: string) => {
    const items = getScheduleForCell(day, hour);
    if (items.length === 0) {
      setFormData((prev) => ({ ...prev, day, startTime: hour }));
      setShowModal(true);
    }
  };

  const handleRightClick = (e: React.MouseEvent, item: ScheduleItem) => {
    e.preventDefault();
    setContextMenu({ x: e.clientX, y: e.clientY, item });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white">Horário Semanal</h1>
        <button
          onClick={() => { resetForm(); setShowModal(true); }}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium text-sm transition-colors"
        >
          <Plus size={16} /> Adicionar Disciplina
        </button>
      </div>

      {/* Schedule Grid */}
      <div className="bg-[#1e293b] rounded-xl border border-[#334155] overflow-x-auto">
        <div className="min-w-[700px]">
          {/* Header row */}
          <div className="grid grid-cols-7 border-b border-[#334155]">
            <div className="p-3 text-xs font-medium text-[#64748b] uppercase tracking-wider border-r border-[#334155]">
              Hora
            </div>
            {days.map((day) => (
              <div
                key={day}
                className="p-3 text-sm font-semibold text-white text-center border-r border-[#334155] last:border-r-0"
              >
                {DAYS_PT[day]}
              </div>
            ))}
          </div>

          {/* Time rows */}
          {HOURS.map((hour) => (
            <div key={hour} className="grid grid-cols-7 border-b border-[#334155] last:border-b-0">
              <div className="p-3 text-xs text-[#64748b] font-mono border-r border-[#334155] flex items-center">
                {hour}
              </div>
              {days.map((day) => {
                const items = getScheduleForCell(day, hour);
                const item = items[0];
                const isStart = item && item.startTime === hour;

                return (
                  <div
                    key={`${day}-${hour}`}
                    className="min-h-[56px] border-r border-[#334155] last:border-r-0 p-1 cursor-pointer hover:bg-[#334155]/30 transition-colors relative"
                    onClick={() => handleCellClick(day, hour)}
                    onContextMenu={(e) => item && handleRightClick(e, item)}
                  >
                    {item && isStart && (
                      <div
                        className="rounded-md p-2 text-xs font-medium text-white h-full flex items-center justify-center text-center"
                        style={{ backgroundColor: item.color + '30', border: `1px solid ${item.color}60` }}
                      >
                        <span className="truncate">{item.subject}</span>
                      </div>
                    )}
                    {item && !isStart && (
                      <div
                        className="rounded-md p-2 text-xs text-white/50 h-full flex items-center justify-center"
                        style={{ backgroundColor: item.color + '15', border: `1px solid ${item.color}30` }}
                      >
                        <span className="truncate opacity-50">{item.subject}</span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      {/* Legend */}
      {schedule.length > 0 && (
        <div className="flex flex-wrap gap-3">
          {Array.from(new Set(schedule.map((s) => s.subject))).map((subject) => {
            const color = schedule.find((s) => s.subject === subject)?.color;
            return (
              <div key={subject} className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: color }} />
                <span className="text-xs text-[#94a3b8]">{subject}</span>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-[#1e293b] rounded-xl border border-[#334155] w-full max-w-md p-6 shadow-xl">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-lg font-semibold text-white">
                {editingId ? 'Editar Disciplina' : 'Adicionar Disciplina'}
              </h2>
              <button onClick={resetForm} className="text-[#64748b] hover:text-white transition-colors">
                <X size={20} />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-[#94a3b8] uppercase tracking-wider mb-1.5">
                  Disciplina
                </label>
                <input
                  type="text"
                  value={formData.subject}
                  onChange={(e) => setFormData((prev) => ({ ...prev, subject: e.target.value }))}
                  placeholder="Ex: Matemática"
                  className={`w-full px-3 py-2.5 bg-[#0f172a] border rounded-lg text-white text-sm placeholder-[#475569] focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.subject ? 'border-red-500' : 'border-[#334155]'
                  }`}
                />
                {errors.subject && <p className="text-red-400 text-xs mt-1">{errors.subject}</p>}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-[#94a3b8] uppercase tracking-wider mb-1.5">
                    Dia
                  </label>
                  <select
                    value={formData.day}
                    onChange={(e) => setFormData((prev) => ({ ...prev, day: e.target.value as DayOfWeek }))}
                    className="w-full px-3 py-2.5 bg-[#0f172a] border border-[#334155] rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {Object.entries(DAYS_PT).map(([key, label]) => (
                      <option key={key} value={key}>{label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#94a3b8] uppercase tracking-wider mb-1.5">
                    Cor
                  </label>
                  <div className="flex gap-2">
                    {DISCIPLINE_COLORS.map((c) => (
                      <button
                        key={c.value}
                        onClick={() => setFormData((prev) => ({ ...prev, color: c.value }))}
                        className={`w-8 h-8 rounded-full transition-transform ${
                          formData.color === c.value ? 'scale-110 ring-2 ring-white' : 'hover:scale-105'
                        }`}
                        style={{ backgroundColor: c.value }}
                        title={c.name}
                      />
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-[#94a3b8] uppercase tracking-wider mb-1.5">
                    Início
                  </label>
                  <select
                    value={formData.startTime}
                    onChange={(e) => setFormData((prev) => ({ ...prev, startTime: e.target.value }))}
                    className="w-full px-3 py-2.5 bg-[#0f172a] border border-[#334155] rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {HOURS.map((h) => (
                      <option key={h} value={h}>{h}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#94a3b8] uppercase tracking-wider mb-1.5">
                    Fim
                  </label>
                  <select
                    value={formData.endTime}
                    onChange={(e) => setFormData((prev) => ({ ...prev, endTime: e.target.value }))}
                    className={`w-full px-3 py-2.5 bg-[#0f172a] border rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                      errors.time ? 'border-red-500' : 'border-[#334155]'
                    }`}
                  >
                    {HOURS.slice(1).map((h) => (
                      <option key={h} value={h}>{h}</option>
                    ))}
                  </select>
                </div>
              </div>
              {errors.time && <p className="text-red-400 text-xs">{errors.time}</p>}

              <button
                onClick={handleSubmit}
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium text-sm transition-colors mt-2"
              >
                {editingId ? 'Guardar Alterações' : 'Adicionar'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Context Menu */}
      {contextMenu && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setContextMenu(null)} />
          <div
            className="fixed z-50 bg-[#1e293b] border border-[#334155] rounded-lg shadow-xl py-1 min-w-[140px]"
            style={{ top: contextMenu.y, left: contextMenu.x }}
          >
            <button
              onClick={() => handleEdit(contextMenu.item)}
              className="w-full flex items-center gap-2 px-3 py-2 text-sm text-[#94a3b8] hover:bg-[#334155] hover:text-white transition-colors"
            >
              <Edit3 size={14} /> Editar
            </button>
            <button
              onClick={() => handleDelete(contextMenu.item.id)}
              className="w-full flex items-center gap-2 px-3 py-2 text-sm text-red-400 hover:bg-red-500/10 transition-colors"
            >
              <Trash2 size={14} /> Remover
            </button>
          </div>
        </>
      )}
    </div>
  );
}
