import { useState, useRef, useCallback } from 'react';
import { useApp } from '@/context/AppContext';
import { Upload, Camera, X, Send, Brain, Sparkles, Loader2, Copy, CheckCircle, BookOpen, HelpCircle, Lightbulb, Layers } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { GoogleGenerativeAI } from '@google/generative-ai';
import type { IAMode } from '@/types';

const MODES: { id: IAMode; label: string; icon: typeof BookOpen; prompt: string }[] = [
  {
    id: 'summarize',
    label: 'Resumir',
    icon: BookOpen,
    prompt: 'Resume o seguinte conteúdo de um manual escolar de forma clara e estruturada, destacando os pontos-chave. Usa markdown para formatar o resumo com títulos e listas quando apropriado:',
  },
  {
    id: 'quiz',
    label: 'Teste-me',
    icon: HelpCircle,
    prompt: 'Cria 5 perguntas de escolha múltipla baseadas neste conteúdo. Para cada pergunta, indica a resposta correta no final. Formata com markdown:',
  },
  {
    id: 'explain',
    label: 'Explicar',
    icon: Lightbulb,
    prompt: 'Explica o conteúdo desta página de manual como se estivesses a ensinar um aluno. Sê claro, usa exemplos práticos e divide em passos. Usa markdown para formatar:',
  },
  {
    id: 'flashcards',
    label: 'Flashcards',
    icon: Layers,
    prompt: 'Cria 6 cartões de estudo (flashcards) a partir deste conteúdo. Cada cartão deve ter uma pergunta/conceito na frente e a resposta no verso. Formato: **FRENTE:** ... / **VERSO:** ...',
  },
];

const API_KEY = import.meta.env.VITE_GEMINI_API_KEY || '';

export default function IA() {
  const { iaHistory, setIaHistory } = useApp();
  const [image, setImage] = useState<string | null>(null);
  const [mode, setMode] = useState<IAMode>('summarize');
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => setImage(reader.result as string);
    reader.readAsDataURL(file);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (!file || !file.type.startsWith('image/')) return;
    const reader = new FileReader();
    reader.onloadend = () => setImage(reader.result as string);
    reader.readAsDataURL(file);
  }, []);

  const generateResponse = async () => {
    if (!image) return;

    const selectedMode = MODES.find((m) => m.id === mode);
    if (!selectedMode) return;

    setLoading(true);
    setResponse('');

    try {
      const genAI = new GoogleGenerativeAI(API_KEY);
      const model = genAI.getGenerativeModel({ model: 'gemini-2.0-flash' });

      // Extract base64 data
      const base64Data = image.split(',')[1];
      const mimeType = image.split(';')[0].split(':')[1];

      const fullPrompt = `${selectedMode.prompt}\n\nPergunta adicional do utilizador: ${prompt || 'Nenhuma'}\n\nAnalisa a imagem fornecida e responde em português de Portugal.`;

      const result = await model.generateContent([
        fullPrompt,
        {
          inlineData: {
            data: base64Data,
            mimeType,
          },
        },
      ]);

      const text = result.response.text();
      setResponse(text);

      // Save to history
      const historyItem = {
        id: crypto.randomUUID(),
        image,
        mode,
        prompt: prompt || selectedMode.label,
        response: text,
        timestamp: new Date().toISOString(),
      };
      setIaHistory((prev) => [historyItem, ...prev].slice(0, 20));
    } catch {
      setResponse('Erro ao processar a imagem. Verifica se a API key do Gemini está configurada corretamente.\n\nPara configurar, define a variável de ambiente `VITE_GEMINI_API_KEY` com a tua chave da API do Google Gemini.');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = async () => {
    await navigator.clipboard.writeText(response);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const loadHistoryItem = (item: (typeof iaHistory)[0]) => {
    setImage(item.image);
    setMode(item.mode as IAMode);
    setResponse(item.response);
    setShowHistory(false);
  };

  const currentMode = MODES.find((m) => m.id === mode);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-bold text-white">Assistente de Estudo IA</h1>
          <span className="px-2.5 py-1 bg-blue-500/10 text-blue-400 text-xs rounded-full flex items-center gap-1">
            <Sparkles size={12} /> Powered by Gemini
          </span>
        </div>
        {iaHistory.length > 0 && (
          <button
            onClick={() => setShowHistory(!showHistory)}
            className="text-sm text-[#94a3b8] hover:text-white transition-colors"
          >
            {showHistory ? 'Voltar' : `Histórico (${iaHistory.length})`}
          </button>
        )}
      </div>

      {!API_KEY && (
        <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4 text-amber-400 text-sm">
          <strong>Nota:</strong> Para usar a funcionalidade de IA, configura a variável de ambiente
          <code className="mx-1 px-1.5 py-0.5 bg-amber-500/20 rounded">VITE_GEMINI_API_KEY</code>
          com a tua chave da API do Google Gemini.
        </div>
      )}

      {showHistory ? (
        /* History View */
        <div className="space-y-3">
          {iaHistory.map((item) => {
            const modeInfo = MODES.find((m) => m.id === item.mode);
            return (
              <button
                key={item.id}
                onClick={() => loadHistoryItem(item)}
                className="w-full bg-[#1e293b] rounded-xl border border-[#334155] p-4 text-left hover:border-[#475569] transition-all"
              >
                <div className="flex items-center gap-3 mb-2">
                  <img src={item.image} alt="" className="w-12 h-12 rounded-lg object-cover" />
                  <div>
                    <span className="text-xs text-blue-400 font-medium">{modeInfo?.label}</span>
                    <p className="text-sm text-[#94a3b8] line-clamp-1">{item.prompt}</p>
                  </div>
                </div>
                <p className="text-xs text-[#475569]">
                  {new Date(item.timestamp).toLocaleDateString('pt-PT')}
                </p>
              </button>
            );
          })}
        </div>
      ) : (
        <>
          {/* Mode Selector */}
          <div className="flex flex-wrap gap-2">
            {MODES.map((m) => (
              <button
                key={m.id}
                onClick={() => setMode(m.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  mode === m.id
                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20'
                    : 'bg-[#1e293b] text-[#94a3b8] hover:text-white border border-[#334155]'
                }`}
              >
                <m.icon size={16} />
                {m.label}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
            {/* Left: Upload & Input */}
            <div className="lg:col-span-3 space-y-4">
              {/* Image Upload Area */}
              {!image ? (
                <div
                  onDrop={handleDrop}
                  onDragOver={(e) => e.preventDefault()}
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-[#334155] hover:border-blue-500/50 rounded-xl p-12 text-center cursor-pointer transition-colors bg-[#1e293b]/50"
                >
                  <Upload size={40} className="text-[#475569] mx-auto mb-3" />
                  <p className="text-white font-medium mb-1">Arrasta uma imagem aqui</p>
                  <p className="text-[#64748b] text-sm mb-4">ou clica para selecionar</p>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      cameraInputRef.current?.click();
                    }}
                    className="inline-flex items-center gap-2 px-4 py-2 bg-[#334155] hover:bg-[#475569] text-white rounded-lg text-sm transition-colors"
                  >
                    <Camera size={16} /> Tirar Foto
                  </button>
                </div>
              ) : (
                <div className="relative bg-[#1e293b] rounded-xl border border-[#334155] p-4">
                  <button
                    onClick={() => { setImage(null); setResponse(''); }}
                    className="absolute top-2 right-2 p-1.5 bg-[#0f172a] rounded-lg text-[#475569] hover:text-red-400 transition-colors z-10"
                  >
                    <X size={14} />
                  </button>
                  <img
                    src={image}
                    alt="Upload"
                    className="max-h-[400px] mx-auto rounded-lg object-contain"
                  />
                </div>
              )}

              {/* Hidden inputs */}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
              />
              <input
                ref={cameraInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handleFileUpload}
                className="hidden"
              />

              {/* Text Input */}
              <div className="flex gap-3">
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder={`Pergunta opcional (ex: "Explica apenas a secção 3")`}
                  className="flex-1 px-4 py-3 bg-[#1e293b] border border-[#334155] rounded-lg text-white text-sm placeholder-[#475569] focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none h-[72px]"
                />
                <button
                  onClick={generateResponse}
                  disabled={!image || loading}
                  className="px-5 py-3 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-colors flex items-center gap-2 self-end"
                >
                  {loading ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
                </button>
              </div>
            </div>

            {/* Right: Results */}
            <div className="lg:col-span-2">
              <div className="bg-[#1e293b] rounded-xl border border-[#334155] min-h-[500px] flex flex-col">
                <div className="flex items-center justify-between p-4 border-b border-[#334155]">
                  <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                    <Brain size={16} className="text-blue-500" />
                    Resposta
                  </h3>
                  {response && (
                    <button
                      onClick={handleCopy}
                      className="p-1.5 text-[#475569] hover:text-blue-400 transition-colors"
                      title="Copiar"
                    >
                      {copied ? <CheckCircle size={16} className="text-emerald-500" /> : <Copy size={16} />}
                    </button>
                  )}
                </div>
                <div className="flex-1 p-4 overflow-y-auto">
                  {loading ? (
                    <div className="flex flex-col items-center justify-center h-full text-center">
                      <Loader2 size={32} className="text-blue-500 animate-spin mb-3" />
                      <p className="text-[#94a3b8] text-sm">A processar a imagem...</p>
                      <p className="text-[#475569] text-xs mt-1">{currentMode?.label}</p>
                    </div>
                  ) : response ? (
                    <div className="prose prose-invert prose-sm max-w-none">
                      <ReactMarkdown>{response}</ReactMarkdown>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-full text-center">
                      <Sparkles size={32} className="text-[#334155] mb-3" />
                      <p className="text-[#64748b] text-sm">
                        Carrega uma imagem e clica em enviar para obteres uma resposta
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
