import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Plus, X, Trash2, FileText, CheckCircle } from 'lucide-react';
import { differenceInDays, parseISO, isPast, isToday, format } from 'date-fns';
import { pt } from 'date-fns/locale';

export default function Testes() {
  const { tests, setTests } = useApp();
  const [showForm, setShowForm] = useState(false);
  const [filter, setFilter] = useState<'upcoming' | 'completed'>('upcoming');
  const [formData, setFormData] = useState({ subject: '', date: '', topic: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.subject.trim()) errs.subject = 'Disciplina obrigatória';
    if (!formData.date) errs.date = 'Data obrigatória';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;

    const newTest = {
      id: crypto.randomUUID(),
      subject: formData.subject,
      date: formData.date,
      topic: formData.topic,
      completed: false,
    };

    setTests((prev) => [...prev, newTest]);
    setFormData({ subject: '', date: '', topic: '' });
    setShowForm(false);
    setErrors({});
  };

  const handleDelete = (id: string) => {
    setTests((prev) => prev.filter((t) => t.id !== id));
  };

  const toggleComplete = (id: string) => {
    setTests((prev) =>
      prev.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t))
    );
  };

  const now = new Date();

  const filteredTests = tests
    .filter((t) => {
      if (filter === 'completed') return t.completed || isPast(parseISO(t.date));
      return !t.completed && !isPast(parseISO(t.date));
    })
    .sort((a, b) => parseISO(a.date).getTime() - parseISO(b.date).getTime());

  const getDaysBadge = (date: string, completed: boolean) => {
    if (completed || isPast(parseISO(date))) {
      return { text: 'Concluído', class: 'bg-[#334155] text-[#64748b]' };
    }

    const days = differenceInDays(parseISO(date), now);

    if (isToday(parseISO(date))) {
      return { text: 'Hoje!', class: 'bg-red-500/20 text-red-400 animate-pulse font-bold' };
    }
    if (days <= 2) return { text: `${days} ${days === 1 ? 'dia' : 'dias'}`, class: 'bg-red-500/20 text-red-400' };
    if (days <= 7) return { text: `${days} dias`, class: 'bg-amber-500/20 text-amber-400' };
    return { text: `${days} dias`, class: 'bg-emerald-500/20 text-emerald-400' };
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-white">Os Meus Testes</h1>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium text-sm transition-colors"
        >
          {showForm ? <X size={16} /> : <Plus size={16} />}
          {showForm ? 'Cancelar' : 'Marcar Teste'}
        </button>
      </div>

      {/* Add Form */}
      {showForm && (
        <div className="bg-[#1e293b] rounded-xl border border-[#334155] p-5">
          <h3 className="text-sm font-semibold text-white mb-4">Novo Teste</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-[#94a3b8] uppercase tracking-wider mb-1.5">
                Disciplina *
              </label>
              <input
                type="text"
                value={formData.subject}
                onChange={(e) => setFormData((prev) => ({ ...prev, subject: e.target.value }))}
                placeholder="Ex: Matemática"
                className={`w-full px-3 py-2.5 bg-[#0f172a] border rounded-lg text-white text-sm placeholder-[#475569] focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  errors.subject ? 'border-red-500' : 'border-[#334155]'
                }`}
              />
              {errors.subject && <p className="text-red-400 text-xs mt-1">{errors.subject}</p>}
            </div>
            <div>
              <label className="block text-xs font-medium text-[#94a3b8] uppercase tracking-wider mb-1.5">
                Data *
              </label>
              <input
                type="date"
                value={formData.date}
                onChange={(e) => setFormData((prev) => ({ ...prev, date: e.target.value }))}
                className={`w-full px-3 py-2.5 bg-[#0f172a] border rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  errors.date ? 'border-red-500' : 'border-[#334155]'
                }`}
              />
              {errors.date && <p className="text-red-400 text-xs mt-1">{errors.date}</p>}
            </div>
            <div>
              <label className="block text-xs font-medium text-[#94a3b8] uppercase tracking-wider mb-1.5">
                Tema / Conteúdo
              </label>
              <input
                type="text"
                value={formData.topic}
                onChange={(e) => setFormData((prev) => ({ ...prev, topic: e.target.value }))}
                placeholder="Opcional"
                className="w-full px-3 py-2.5 bg-[#0f172a] border border-[#334155] rounded-lg text-white text-sm placeholder-[#475569] focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
          <button
            onClick={handleSubmit}
            className="mt-4 px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium text-sm transition-colors"
          >
            Marcar Teste
          </button>
        </div>
      )}

      {/* Filter Tabs */}
      <div className="flex gap-2">
        <button
          onClick={() => setFilter('upcoming')}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
            filter === 'upcoming'
              ? 'bg-blue-600 text-white'
              : 'bg-[#1e293b] text-[#94a3b8] hover:text-white border border-[#334155]'
          }`}
        >
          Próximos
        </button>
        <button
          onClick={() => setFilter('completed')}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
            filter === 'completed'
              ? 'bg-blue-600 text-white'
              : 'bg-[#1e293b] text-[#94a3b8] hover:text-white border border-[#334155]'
          }`}
        >
          Concluídos
        </button>
      </div>

      {/* Tests List */}
      {filteredTests.length === 0 ? (
        <div className="bg-[#1e293b] rounded-xl border border-[#334155] p-12 text-center">
          <FileText size={40} className="text-[#334155] mx-auto mb-3" />
          <p className="text-[#64748b] text-sm">
            {filter === 'upcoming' ? 'Ainda não tens testes marcados' : 'Nenhum teste concluído'}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredTests.map((test) => {
            const badge = getDaysBadge(test.date, test.completed || isPast(parseISO(test.date)));
            return (
              <div
                key={test.id}
                className="bg-[#1e293b] rounded-xl border border-[#334155] p-4 flex items-center gap-4 hover:border-[#475569] transition-all duration-200"
              >
                {/* Checkbox */}
                <button
                  onClick={() => toggleComplete(test.id)}
                  className={`flex-shrink-0 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${
                    test.completed || isPast(parseISO(test.date))
                      ? 'bg-emerald-500 border-emerald-500'
                      : 'border-[#475569] hover:border-emerald-500'
                  }`}
                >
                  {(test.completed || isPast(parseISO(test.date))) && <CheckCircle size={14} className="text-white" />}
                </button>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <p className={`font-semibold text-white truncate ${test.completed ? 'line-through opacity-50' : ''}`}>
                    {test.subject}
                  </p>
                  {test.topic && (
                    <p className={`text-sm text-[#64748b] truncate ${test.completed ? 'line-through opacity-50' : ''}`}>
                      {test.topic}
                    </p>
                  )}
                  <p className="text-xs text-[#475569] mt-0.5">
                    {format(parseISO(test.date), "dd 'de' MMMM 'de' yyyy", { locale: pt })}
                  </p>
                </div>

                {/* Badge */}
                <span className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap ${badge.class}`}>
                  {badge.text}
                </span>

                {/* Delete */}
                <button
                  onClick={() => handleDelete(test.id)}
                  className="flex-shrink-0 p-2 text-[#475569] hover:text-red-400 transition-colors"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
